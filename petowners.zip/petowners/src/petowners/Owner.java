package petowners;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

/**
 *
 * @author Jiaxin Jiang, D00217246
 */
public class Owner implements Comparator<Pet>
{

    private String ownerId;
    private String name;
    private List<Pet> pets;


    public Owner()
    {
        this.name = "";
        this.ownerId = "OID" + 0;
        this.pets = new ArrayList();
    }

    public Owner(String ownerId, String name)
    {
        this.ownerId = ownerId;
        this.name = name;
        this.pets = new ArrayList();
    }

    /**
     *
     * @return name
     */
    public String getName()
    {
        return name;
    }

    /**
     *
     * @return ownerId
     */
    public String getOwnerId()
    {
        return ownerId;
    }



    /**
     *
     * @return a list of Pet objects
     */
    public List<Pet> getPets()
    {
        return pets;
    }

    /**
     *
     * @param name
     */
    public void setName(String name)
    {
        this.name = name;
    }


    public void addPet(Pet p)
    {
        pets.add(p);
    }

    public void addPet(String petId, String type, String name, int age)
    {
        addPet(new Pet(petId, type, name,  age,  ownerId));
    }
    

    public void removePet(String petId)
    {
        if (hasPet(petId))
        {
            pets.remove(pets.get(findPet(petId)));
        }
    }


    public void removeAllPets()
    {
        pets.removeAll(pets);
    }


    /**
     * Find the position of a Pet object in the pets list; return -1 if not
     * found

     */
    public int findPet(String petId)
    {
        int pos = -1;
        int i = 0;
        while (i < pets.size() && pos == -1)
        {
            if (pets.get(i).getPetId().equalsIgnoreCase(petId))
            {
                pos = i;
            }
            else
            {
                i++;
            }
        }
        return pos;
    }

    /**
     * Determine if a Pet object exists in the pets list
     *
     * @param petId
     * @return true or false
     */
    public boolean hasPet(String petId)
    {
        return findPet(petId) != -1;
    }

    public String printPets()
    {
        String out="";
        for (Pet p: pets){
            out=out+p.toString();
        }
        return out;
    }
    
    public int maxAge()
    {
        int maxage=-1;

        for (Pet p: pets){
            if(p.getAge()>maxage){
                maxage = p.getAge();
            }
        }

        return maxage;
    }
    
    public int getPetsAboveAge(int cutOffAge)
    {
        int numAbove=0;
        
        for (Pet p: pets){
            if(p.getAge()>cutOffAge){
                numAbove++;
            }
        }
        
        return numAbove;
    }
    
    
    @Override
    public int compare(Pet a, Pet b)
    {
        if (a.getAge() < b.getAge())
        {
            return -1;
        }
        else if (a.getAge() > b.getAge())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    
    
    @Override
    public String toString()
    {
        return getClass().getSimpleName() + "{" + "name=" + name + ", ownerId=" + ownerId + ", pets=" + printPets() + '}';
    }
}
