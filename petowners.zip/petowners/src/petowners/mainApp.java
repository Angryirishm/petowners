/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petowners;
import java.util.Scanner;
/**
 *
 * @author Playertek
 */
public class mainApp {
    public static void main(String[] args) {

        
        
        Scanner sc = new Scanner(System.in);

        int menuSelection = 1;
        System.out.println("Welcome to the Pet Registry System");
        
        while(menuSelection !=0){
            System.out.println("Enter 1 to investigate the pets by age. Enter 0 to exit");
            menuSelection = sc.nextInt();
            if(menuSelection ==1){
                Owner o1 = loadDefaultData();
                
                System.out.println("Enter Cutoff Age(>=0):");
                
                int cutOffAge = sc.nextInt();
                
                int numPets = o1.getPetsAboveAge(cutOffAge);
                System.out.println("The number of pets above your chosen age is: "+ numPets);
                
            }
        }
        
        
    }
    
    public static Owner loadDefaultData(){
        Owner o1 = new Owner("OID57","John");
        o1.addPet("PID01","dog","bowwow",3);
        o1.addPet("PID02","dog","shep",5);
        o1.addPet("PID03","cat","meow",5);
        o1.addPet("PID04","snake","wally",8);
        o1.addPet("PID05","bear","stephen",14);
        o1.addPet("PID06","horse","flier",7);
        o1.addPet("PID07","gerbil","gerb",1);
        
        return o1;
    }
}
