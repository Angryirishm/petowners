/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petowners;


/**
 *
 * @author Playertek
 */

    
public class Pet 
{

    private String type;
    private String name;
    private int age;
    private String petId;
    private String ownerId;


    public Pet()
    {
        this.petId="";
        this.type = "";
        this.name = "";
        this.age = 0;
        this.petId = "PID" + 0;
        this.ownerId = "";
    }

    /**

     */
    public Pet(String petId, String type, String name,  int age,  String ownerId)
    {
        this.petId = petId;
        this.type = type;
        this.name = name;
        this.setAge(age);
        this.ownerId = ownerId;
    }

    /**
     *
     * @return type
     */
    public String getType()
    {
        return type;
    }

    /**
     *
     * @return name
     */
    public String getName()
    {
        return name;
    }


    /**
     *
     * @return age
     */
    public int getAge()
    {
        return age;
    }



    /**
     *
     * @return petId
     */
    public String getPetId()
    {
        return petId;
    }

    /**
     *
     * @return ownerId
     */
    public String getOwnerId()
    {
        return ownerId;
    }



    /**
     *
     * @param type
     */
    public void setType(String type)
    {
        this.type = type;
    }

    /**
     *
     * @param name
     */
    public void setName(String name)
    {
        this.name = name;
    }



    /**
     * Check if age is >= 0, throw exception if not
     *
     * @param age
     */
    public void setAge(int age)
    {
        if (age < 0)
        {
            throw new IllegalArgumentException("INVALID - AGE MUST BE >= 0");
        }
        this.age = age;
    }



    /**
     *
     * @param ownerId
     */
    public void setOwnerId(String ownerId)
    {
        this.ownerId = ownerId;
    }



    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        Pet other = (Pet) obj;
        if (this.age != other.age)
        {
            return false;
        }
        if (!(this.type.equalsIgnoreCase(other.type)))
        {
            return false;
        }
        if (!(this.name.equalsIgnoreCase(other.name)))
        {
            return false;
        }
       
        return true;
    }


    @Override
    public String toString()
    {
        return getClass().getSimpleName() + "{" + "type=" + type + ", name=" + name + ", age=" + age + ", petId=" + petId + ", ownerId=" + ownerId + '}';
    }
    
}
