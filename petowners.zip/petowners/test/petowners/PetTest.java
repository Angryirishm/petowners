/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petowners;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author D00218440
 */
public class PetTest {

    public PetTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getType method, of class Pet.
     */
    @Test
    public void testGetType() {
        System.out.println("getType");
        Pet instance = new Pet();
        instance.setType("dog");
        String expResult = "dog";
        String result = instance.getType();
        assertEquals(expResult, result);
    }

    /**
     * Test of toString method, of class Pet.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Pet instance = new Pet("PID001", "dog", "bowwow", 3, "OID1");
        String expResult = "Pet{type=dog, name=bowwow, age=3, petId=PID001, ownerId=OID1}";
        String result = instance.toString();
        assertEquals(expResult, result);
    }

    
   
     /**
     * Test of equals method, of class Pet.
     */
    @Test
    public void testEquals1() {
        System.out.println("equals");
        Object obj = null;
        Pet instance = new Pet();
        
        boolean expResult = true;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
    }
    
       @Test
    public void testEquals2() {
        System.out.println("equals");
        Object obj = null;
        Pet instance = new Pet();
        boolean expResult = false;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
    }
}
